export default {"origin":"https://bnitz-routing.enricobottazzi.workers.dev"};
