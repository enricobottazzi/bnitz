export default {"origin":"https://bnitz-routing-0-2-3.enricobottazzi.workers.dev"};
